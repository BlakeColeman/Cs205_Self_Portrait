let lx;
let rx;
let y;
let size;

function setup() {
  createCanvas(400, 400);
  mic = new p5.AudioIn();
  mic.start();
}

function draw() {
  background(220);
  drawStatic();
  drawMouth();
  drawEyes();
}

//Function for the static parts of the face
function drawStatic()
{
  fill(0,0,255);
  //Draw Shirt
  arc(200,400,300,250,PI,TWO_PI,OPEN);
  fill(255,255,180);
  //Draw Ears
  arc(100,200,40,60,PI+HALF_PI,PI+HALF_PI,OPEN);
  arc(300,200,40,60,PI+HALF_PI,PI+HALF_PI,OPEN);
  //Draw Face
  ellipse (200,200,200);
  fill(240,240,200);
  //Draw Nose
  triangle(200,210,180,230,220,230);
  fill(32,19,19);
  //Draw Hair
  arc(200,130,150,60,PI,0,OPEN);
  //Draw Ears
  arc(155,150,45,15,PI,TWO_PI,OPEN);
  arc(245,150,45,15,PI,TWO_PI,OPEN);
}
//Function for drawing Mouth
function drawMouth()
{
  mouthSize();
  fill(0);
  ellipse(200, 260, 2*size+25, size+10);
}
//Function to set the size of the mouth based on input from the microphone
function mouthSize()
{
  micLevel = mic.getLevel();
  size = 200*micLevel;
}
//Function for Drawing Eyes
function drawEyes()
{
  lx = leftX();
  rx = rightX();
  y =  eyeY();
  fill(355);
  ellipse (150,190,70);
  ellipse (250,190,70);
  fill(0);
  ellipse (lx-50,y,10);
  ellipse (rx+50,y,10);
}
//Function to set x-coordinate for left eye so it follows the mouse but remains within eye
function leftX() 
{
  if (mouseX>=180 && mouseX<=220)
  return mouseX;
  else if (mouseX<=180) 
  return 180;
  else
  return 220;
}
//Function to set x-coordinate for right eye so it follows the mouse but remains within eye
function rightX()
{
  if (mouseX>=180 && mouseX<=220)
  return mouseX;
  else if (mouseX<=180) 
  return 180;
  else
  return 220;
}
//Function to set y-coordinate for both eyes so they follows the mouse but remains within eye
function eyeY()
{
  if (mouseY<=210 && mouseY>=170)
  return mouseY;
  else if (mouseY>=190)
  return 210;
  else
  return 170;
}